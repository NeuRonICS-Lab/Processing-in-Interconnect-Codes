`timescale 1ns/1ps
module conv_cbs_tb;
    localparam int CW = 8;
    logic clk = 0, rst_n;
    logic is_tx = 0, is_gap = 0, has_pkt = 0, en = 1;
    logic [1:0] occ;
    logic [2:0] idle_rate;
    logic signed [CW-1:0] spend = 2, lim = 0, minc = -70, maxc = 50;
    logic gate_open, sys_int;
    logic signed [CW-1:0] credit_out;
    pi2_cbs #(.CREDIT_WIDTH(CW), .FIFO_DEPTH(2)) dut (
        .clk(clk), .rst_n(rst_n),
        .is_transmitting(is_tx), .is_interpacket_gap(is_gap),
        .has_available_packet(has_pkt), .credit_counter_en(en),
        .idle_credit_gain_rate(idle_rate), .transmit_credit_spend_rate(spend),
        .transmit_credit_limit(lim), .min_credit(minc), .max_credit(maxc),
        .gate_open(gate_open), .sys_interrupt(sys_int), .credit_out(credit_out)
    );
    always #0.5 clk = ~clk;

    int pass_count = 0, fail_count = 0;
    task automatic check(input bit cond, input string desc);
        if (cond) begin pass_count++; $display("[PASS] %s", desc); end
        else begin fail_count++; $display("[FAIL] %s", desc); end
    endtask

    task automatic step(input string label);
        @(posedge clk);
        $display("%-32s occ=%0d  credit=%0d  is_tx=%0b  has_pkt=%0b  gate_open=%0b",
                   label, occ, credit_out, is_tx, has_pkt, gate_open);
        if (gate_open && occ > 0)   // guarded: occ is explicitly scripted below to
            occ -= 1;               // match the figure, so this must not underflow
    endtask

    initial begin
        rst_n = 0; occ = 2'd0;
        idle_rate = 3'd3;   // deliberately NOT a multiple of spend_rate(2), so the
                             // final reset-to-0 step is visibly a snap, not just
                             // decay happening to land on 0 by coincidence
        @(posedge clk); @(posedge clk); #1; rst_n = 1;

        // idle: nothing queued, nothing transmitting -- credit pinned at 0
        step("idle");
        step("idle");
        check(credit_out == 0, "idle: credit pinned at 0");

        // AV frame becomes available while legacy traffic holds the medium.
        // "number of AV queued frames" -> 1. is_tx stays 0 (this shaper's
        // own class isn't transmitting -- something else has the medium),
        // so credit climbs at idle_credit_gain_rate while it waits.
        has_pkt = 1; occ = 2'd1;
        step("queued, waiting on legacy tx");
        step("queued, waiting on legacy tx");
        step("queued, waiting on legacy tx");
        step("queued, waiting on legacy tx");
        step("queued, waiting on legacy tx");
        check(credit_out == 15, $sformatf("after waiting: credit climbed to idle_rate*5=15 (got %0d)", credit_out));

        // legacy frame finishes -- AV frame starts transmitting immediately.
        // It stops "waiting" the instant it starts (occ->0, has_pkt->0), but
        // credit keeps moving because is_transmitting overrides the
        // has_available_packet check -- it's SPENT, not reset. This is the
        // "credits withdrawn when no frames are waiting" case in the figure.
        is_tx = 1; has_pkt = 0; occ = 2'd0;
        step("transmitting AV frame");
        step("transmitting AV frame");
        step("transmitting AV frame");
        step("transmitting AV frame");
//        step("transmitting AV frame");
//        step("transmitting AV frame");
        check(credit_out == 3, $sformatf("after tx: credit spent down by spend_rate*6=12, 15-12=3 (got %0d)", credit_out));

        // AV frame finished, no new frame queued -- next cycle neither
        // has_pkt nor is_tx hold, so credit is withdrawn (snapped to 0),
        // NOT decayed to it -- one more spend step from 3 would give 1, not
        // 0, so landing on exactly 0 here confirms the reset rule fired
        // rather than another ordinary spend cycle.
        is_tx = 0;
        step("done, no frames waiting");
        check(credit_out == 0, "done: credit snapped to exactly 0, not decayed (would be 1 if still spending)");
        step("idle");
        step("idle");
        check(credit_out == 0, "idle again: credit stays pinned at 0");

        $display("");
        $display("=== cbs_tb_new: %0d/%0d checks pass ===", pass_count, pass_count+fail_count);
        $finish;
    end
endmodule