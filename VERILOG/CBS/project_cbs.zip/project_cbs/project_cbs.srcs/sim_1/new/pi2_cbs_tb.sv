`timescale 1ns/1ps
module pi2_cbs_tb;
    localparam int CW = 8;
    logic clk = 0, rst_n;
    logic is_tx = 0, is_gap = 0, has_pkt = 0, en = 1;
    logic [1:0] occ;
    logic [2:0] idle_rate;
    assign idle_rate = {1'b0, occ};   // pi2: queue occupancy IS the idle-credit slope --
                                       // not an independent constant like the earlier demo
    logic signed [CW-1:0] spend = 2, lim = 9, minc = -70, maxc = 50;
    logic gate_open, sys_int;
    logic signed [CW-1:0] credit_out;
    pi2_cbs #(.CREDIT_WIDTH(CW), .FIFO_DEPTH(2)) dut (
        .clk(clk), .rst_n(rst_n),
        .is_transmitting(is_tx), .is_interpacket_gap(is_gap),
        .has_available_packet(has_pkt), .credit_counter_en(en),
        .idle_credit_gain_rate(idle_rate), .transmit_credit_spend_rate(spend),
        .transmit_credit_limit(lim), .min_credit(minc), .max_credit(maxc),
        .gate_open(gate_open), .sys_interrupt(sys_int), .credit_out(credit_out)
    );
    always #0.5 clk = ~clk;

    int pass_count = 0, fail_count = 0;
    task automatic check(input bit cond, input string desc);
        if (cond) begin pass_count++; $display("[PASS] %s", desc); end
        else begin fail_count++; $display("[FAIL] %s", desc); end
    endtask

    task automatic step(input string label);
        @(posedge clk);
        $display("%-32s occ=%0d  credit=%0d  is_tx=%0b  has_pkt=%0b  gate_open=%0b",
                   label, occ, credit_out, is_tx, has_pkt, gate_open);
    endtask

    initial begin
        rst_n = 0; occ = 2'd0;
        @(posedge clk); @(posedge clk); #1; rst_n = 1;

        // idle: nothing queued -- idle_rate=occ=0, credit pinned at 0
        step("idle");
        check(credit_out == 0, "idle: credit pinned at 0");

        // pkt1 arrives: occ=1 drives idle_rate=1 directly (continuous
        // assign) -- credit climbs +1/cycle
        occ = 2'd1; has_pkt = 1;
        step("pkt1 queued (occ=1 -> slope=1)");
        step("pkt1 queued (occ=1 -> slope=1)");
        step("pkt1 queued (occ=1 -> slope=1)");
        check(credit_out == 3, $sformatf("after pkt1: credit climbed at slope=1 for 3 cycles (got %0d)", credit_out));

        // pkt2 arrives: occ=2 -> idle_rate=2, slope steepens to +2/cycle
        occ = 2'd2;
        step("pkt2 queued (occ=2 -> slope=2)");
        check(credit_out == 5, $sformatf("after pkt2 arrives: one cycle at slope=2, 3+2=5 (got %0d)", credit_out));

        // keep climbing at slope=2 until credit reaches the threshold --
        // polled rather than a fixed cycle count, so this holds for any lim
        while (credit_out < lim)
            step("climbing to threshold (slope=2)");
        check(credit_out >= lim, $sformatf("threshold reached: credit=%0d >= lim=%0d", credit_out, lim));

        // threshold reached: gate_open needs credit>=lim AND is_transmitting
        // simultaneously (that's the DUT's actual condition), so is_tx is
        // asserted for exactly the cycle that registers the threshold-
        // crossing credit. One packet goes out, and the queue clears
        // entirely (occ->0, not occ-1) -- occupancy here stands for a
        // computed magnitude, not a literal count of packets in flight.
        is_tx = 1;
        step("threshold reached -- gate opens, pkt sent");
        check(gate_open, "gate_open asserted the cycle credit reached the threshold");
        is_tx = 0; has_pkt = 0; occ = 2'd0;

        // neither has_pkt nor is_tx hold now -- credit withdrawn to 0
        step("done -- credit withdrawn to 0");
        check(credit_out == 0, "credit reset to 0 immediately after the packet was sent");
        step("idle");
        check(credit_out == 0, "idle again: credit stays at 0");

        $display("");
        $display("=== cbs_tb_new (pi2 mode): %0d/%0d checks pass ===", pass_count, pass_count+fail_count);
        $finish;
    end
endmodule