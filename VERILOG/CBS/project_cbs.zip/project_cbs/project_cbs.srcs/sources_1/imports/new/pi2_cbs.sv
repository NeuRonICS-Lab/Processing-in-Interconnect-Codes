
// conv_cbs_regressed.sv
// Exact logic of the delivered conv_cbs.sv (module renamed only), kept
// as-is for differential comparison against conv_cbs_fixed.

module pi2_cbs #(
    parameter int CREDIT_WIDTH = 8,
    parameter int FIFO_DEPTH = 2
) (
    input  logic                            clk,
    input  logic                            rst_n,
    input  logic                            is_transmitting,
    input  logic                            is_interpacket_gap,
    input  logic                            has_available_packet,
    input  logic                            credit_counter_en,
    input  logic  [2:0]  idle_credit_gain_rate,
    input  logic signed [CREDIT_WIDTH-1:0]  transmit_credit_spend_rate,
    input  logic signed [CREDIT_WIDTH-1:0]  transmit_credit_limit,
    input  logic signed [CREDIT_WIDTH-1:0]  min_credit,
    input  logic signed [CREDIT_WIDTH-1:0]  max_credit,
    output logic                            gate_open,
    output logic                            sys_interrupt,
    output logic signed [CREDIT_WIDTH-1:0]  credit_out
);
    logic signed [CREDIT_WIDTH-1:0] current_credit, credit_next;
    logic                           prev_interpacket_gap;
    always_comb begin
        logic signed [CREDIT_WIDTH-1:0] gain_rate;
        credit_next = current_credit;
        if (credit_counter_en) begin
            if (!has_available_packet && !is_transmitting)
                credit_next = 0;
            else begin
                if (is_transmitting || is_interpacket_gap)
                    gain_rate = -transmit_credit_spend_rate;
                else if ((current_credit < 0) || has_available_packet)
                    gain_rate = idle_credit_gain_rate;
                else
                    gain_rate = '0;
                credit_next = current_credit + gain_rate;
            end
            if (credit_next > max_credit)      credit_next = max_credit;
            else if (credit_next < min_credit) credit_next = min_credit;
        end
    end
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            current_credit       <= '0;
            prev_interpacket_gap <= 1'b0;
        end else begin
            current_credit       <= credit_next;
            prev_interpacket_gap <= is_interpacket_gap;
        end
    end
    always_comb begin
        gate_open     = (current_credit >= transmit_credit_limit && is_transmitting);
        sys_interrupt = (current_credit >= max_credit) || (current_credit <= min_credit);
        credit_out    = credit_next;
    end
endmodule