## Clock constraints
## ============================================================
create_clock -period 10.000 -name clk -waveform {0.000 5.000} [get_ports clk]

## Typical clock uncertainty allowance (jitter/skew margin).
## Tune this once you have real PLL/MMCM jitter numbers.
##set_clock_uncertainty 0.100 [get_clocks clk]
#set_min_delay -from [get_pins {core0/ingress/in_wr_ptr_reg[0][0]/C}] -to [get_pins {core0/ingress/in_fifo_reg[0][0]_0_1_0_9/RAMH/ADR0}] -0.100

#set_max_delay -from core0/ingress/in_wr_ptr_reg[0][0]/C -through core0/ingress/in_fifo_reg[0][0]_0_1_0_9/RAMH_D1/ADR0 0.100
#set_max_delay -from core0/ingress/in_wr_ptr_reg[0][0]/C -through core0/ingress/in_fifo_reg[0][0]_0_1_0_9/RAMH/ADR0 -to core0/ingress/in_fifo_reg[0][0]_0_1_0_9/RAMH/ADR0 0.100
